# OpenSearch addon for 绅士仓库

Search cangku in firefox.

## How to build

Run `makexpi.sh` on any Linux & BSD. You need to install 7zip first.

## License

WTFPL